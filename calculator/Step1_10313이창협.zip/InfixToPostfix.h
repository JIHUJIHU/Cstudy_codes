#ifndef INFIXTOPOSTFIX_H_INCLUDED
#define INFIXTOPOSTFIX_H_INCLUDED

void convertToPostfix(char exp[]);

#endif // INFIXTOPOSTFIX_H_INCLUDED
