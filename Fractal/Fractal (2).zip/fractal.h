//#ifndef FRACTAL_H_INCLUDED
//#define FRACTAL_H_INCLUDED

#include <windows.h>

void SierpinskiTrialgle(HDC hDC, PAINTSTRUCT* ps, RECT* rect);
void SierpinskiCarpet(HDC hDC, PAINTSTRUCT* ps, RECT* rect);
void OtherFractal(HDC hDC, PAINTSTRUCT* ps, RECT* rect);

//#endif // FRACTAL_H_INCLUDED
