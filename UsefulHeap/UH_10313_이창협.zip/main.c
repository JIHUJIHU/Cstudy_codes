#include <stdio.h>
#include <stdlib.h>
#include "UsefulHeap.h"

int comp(HData d1,HData d2)
{
    return d2-d1;
}


int main()
{
    Heap heap;

    HeapInit(&heap,comp);

    HInsert(&heap, 'A');
    HInsert(&heap, 'C');
    HInsert(&heap, 'B');
    HInsert(&heap, 'E');
    HInsert(&heap, 'D');

    HInsert(&heap, 'a');
    HInsert(&heap, 'b');
    HInsert(&heap, 'c');
    HInsert(&heap, 'e');
    HInsert(&heap, 'd');

    while(!HIsEmpty(&heap))
        printf("%c ",HDelete(&heap));
    return 0;
}
